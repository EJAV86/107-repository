import pymongo
import certifi

con_str =

client = pymongo.MongoClient(con_str, tlsCAFile=certifi.where())
db = 
